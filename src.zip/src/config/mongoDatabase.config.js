module.exports = {
    url: 'mongodb+srv://rinteger:admin@rinteger-z6qz7.mongodb.net/test?retryWrites=true&w=majority'
}